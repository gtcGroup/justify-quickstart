# justify-quickstart
Justify supports JUnit testing with "real" (functionally equivalent) services, relegating mocks to the role of servicing reluctant collaborators. Follow instructions <a href="http://pedcentral.com/justify/justify-quickstart/" target="_blank">here</a> for exploration.

<a href="http://pedcentral.com/justify/" target="_blank">
<img src="http://i1.wp.com/pedcentral.com/wp-content/uploads/2015/01/Justify-e1457816173825.png" alt="PED Central">
</a>

### <a name="changes"></a>Release Notes

#### Version 1.2.0 <span class="date">2017-xx-xx</span>

*   1 [Launch Project](https://github.com/gtcGroup/justify-quickstart/issues/1)
